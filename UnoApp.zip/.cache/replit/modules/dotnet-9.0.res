{"type":"resolve","resolvedModuleId":"dotnet-9.0","inputHash":"","resolutionPath":["dotnet-9.0"],"error":"","Changed":true}
